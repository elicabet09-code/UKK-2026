<?php
//includes/cek_session.php
session_start();

if(!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header('location: login.php');
    exit;
}
?>